
const DEMO_LISTINGS = [{"id": 1, "source": "GİB", "brand": "Mercedes-Benz", "model": "E 220 d", "year": 2018, "city": "Gaziantep", "auctionPrice": 1080000, "marketPrice": 1520000, "deadline": "2026-08-25T15:00:00", "km": 126000, "fuel": "Dizel", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 2, "source": "UYAP", "brand": "BMW", "model": "520i", "year": 2019, "city": "İstanbul", "auctionPrice": 1450000, "marketPrice": 1825000, "deadline": "2026-08-27T11:30:00", "km": 98000, "fuel": "Benzin", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 3, "source": "Ticaret Bakanlığı", "brand": "Audi", "model": "A6 40 TDI", "year": 2020, "city": "Ankara", "auctionPrice": 1960000, "marketPrice": 2525000, "deadline": "2026-08-29T16:00:00", "km": 84000, "fuel": "Dizel", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 4, "source": "GİB", "brand": "Volkswagen", "model": "Passat 1.5 TSI", "year": 2021, "city": "Şanlıurfa", "auctionPrice": 1280000, "marketPrice": 1540000, "deadline": "2026-08-31T10:00:00", "km": 72000, "fuel": "Benzin", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 5, "source": "UYAP", "brand": "Mercedes-Benz", "model": "C 200", "year": 2020, "city": "Adana", "auctionPrice": 1675000, "marketPrice": 2190000, "deadline": "2026-09-01T14:00:00", "km": 91000, "fuel": "Benzin", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 6, "source": "GİB", "brand": "BMW", "model": "320i", "year": 2022, "city": "Gaziantep", "auctionPrice": 1790000, "marketPrice": 2180000, "deadline": "2026-09-02T13:00:00", "km": 51000, "fuel": "Benzin", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 7, "source": "Ticaret Bakanlığı", "brand": "Volvo", "model": "XC60 B5", "year": 2021, "city": "Mersin", "auctionPrice": 2120000, "marketPrice": 2860000, "deadline": "2026-08-26T17:00:00", "km": 77000, "fuel": "Hibrit", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 8, "source": "UYAP", "brand": "Toyota", "model": "Corolla 1.5 Vision", "year": 2022, "city": "Konya", "auctionPrice": 860000, "marketPrice": 1110000, "deadline": "2026-08-28T12:00:00", "km": 64000, "fuel": "Benzin", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 9, "source": "GİB", "brand": "Ford", "model": "Transit 350 L", "year": 2020, "city": "Gaziantep", "auctionPrice": 790000, "marketPrice": 1090000, "deadline": "2026-08-25T18:00:00", "km": 156000, "fuel": "Dizel", "gear": "Manuel", "url": "#", "note": "Örnek veri"}, {"id": 10, "source": "UYAP", "brand": "Renault", "model": "Megane Sedan", "year": 2021, "city": "Bursa", "auctionPrice": 720000, "marketPrice": 930000, "deadline": "2026-09-04T10:30:00", "km": 88000, "fuel": "Dizel", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 11, "source": "Ticaret Bakanlığı", "brand": "Mercedes-Benz", "model": "Vito 119 CDI", "year": 2019, "city": "İzmir", "auctionPrice": 1190000, "marketPrice": 1650000, "deadline": "2026-08-30T15:30:00", "km": 144000, "fuel": "Dizel", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 12, "source": "GİB", "brand": "Skoda", "model": "Superb 1.5 TSI", "year": 2021, "city": "Kayseri", "auctionPrice": 1160000, "marketPrice": 1490000, "deadline": "2026-09-06T14:00:00", "km": 69000, "fuel": "Benzin", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 13, "source": "UYAP", "brand": "Audi", "model": "A4 35 TFSI", "year": 2022, "city": "İstanbul", "auctionPrice": 1640000, "marketPrice": 2180000, "deadline": "2026-09-03T16:00:00", "km": 46000, "fuel": "Benzin", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 14, "source": "GİB", "brand": "Fiat", "model": "Egea Cross", "year": 2023, "city": "Gaziantep", "auctionPrice": 740000, "marketPrice": 990000, "deadline": "2026-08-26T09:30:00", "km": 39000, "fuel": "Dizel", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 15, "source": "Ticaret Bakanlığı", "brand": "BMW", "model": "X3 xDrive20d", "year": 2020, "city": "Antalya", "auctionPrice": 2050000, "marketPrice": 2790000, "deadline": "2026-09-08T11:00:00", "km": 93000, "fuel": "Dizel", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 16, "source": "UYAP", "brand": "Peugeot", "model": "3008 1.5 BlueHDi", "year": 2021, "city": "Adana", "auctionPrice": 1080000, "marketPrice": 1430000, "deadline": "2026-08-28T17:30:00", "km": 81000, "fuel": "Dizel", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 17, "source": "GİB", "brand": "Hyundai", "model": "Tucson 1.6 T-GDI", "year": 2022, "city": "Diyarbakır", "auctionPrice": 1280000, "marketPrice": 1660000, "deadline": "2026-09-05T13:00:00", "km": 57000, "fuel": "Benzin", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 18, "source": "UYAP", "brand": "Volkswagen", "model": "Tiguan 1.5 TSI", "year": 2021, "city": "Ankara", "auctionPrice": 1420000, "marketPrice": 1840000, "deadline": "2026-08-27T17:00:00", "km": 76000, "fuel": "Benzin", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 19, "source": "Ticaret Bakanlığı", "brand": "Land Rover", "model": "Range Rover Evoque", "year": 2019, "city": "İstanbul", "auctionPrice": 1890000, "marketPrice": 2630000, "deadline": "2026-09-02T16:30:00", "km": 104000, "fuel": "Dizel", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 20, "source": "GİB", "brand": "Honda", "model": "Civic 1.5 Turbo", "year": 2021, "city": "Mersin", "auctionPrice": 970000, "marketPrice": 1260000, "deadline": "2026-08-29T10:00:00", "km": 73000, "fuel": "Benzin", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 21, "source": "UYAP", "brand": "Mercedes-Benz", "model": "GLC 220 d", "year": 2020, "city": "Ankara", "auctionPrice": 2180000, "marketPrice": 2940000, "deadline": "2026-09-07T15:00:00", "km": 86000, "fuel": "Dizel", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 22, "source": "GİB", "brand": "BMW", "model": "730Ld xDrive", "year": 2018, "city": "İzmir", "auctionPrice": 1980000, "marketPrice": 2850000, "deadline": "2026-08-30T12:00:00", "km": 132000, "fuel": "Dizel", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 23, "source": "Ticaret Bakanlığı", "brand": "Porsche", "model": "Macan", "year": 2018, "city": "İstanbul", "auctionPrice": 2250000, "marketPrice": 3250000, "deadline": "2026-09-10T14:30:00", "km": 118000, "fuel": "Benzin", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}, {"id": 24, "source": "UYAP", "brand": "Cupra", "model": "Formentor 1.5 TSI", "year": 2022, "city": "Bursa", "auctionPrice": 1490000, "marketPrice": 1930000, "deadline": "2026-09-03T11:00:00", "km": 48000, "fuel": "Benzin", "gear": "Otomatik", "url": "#", "note": "Örnek veri"}];

const STORE = {
  get(key, fallback){
    try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; }
  },
  set(key, value){ localStorage.setItem(key, JSON.stringify(value)); }
};

let state = {
  listings: STORE.get("ir_listings", DEMO_LISTINGS),
  favorites: new Set(STORE.get("ir_favorites", [])),
  alerts: STORE.get("ir_alerts", []),
  compare: new Set(),
  layout: STORE.get("ir_layout", "cards"),
  theme: STORE.get("ir_theme", "dark"),
  currentView: "dashboard"
};

const $ = id => document.getElementById(id);
const $$ = sel => [...document.querySelectorAll(sel)];
const money = n => new Intl.NumberFormat("tr-TR",{style:"currency",currency:"TRY",maximumFractionDigits:0}).format(Number(n)||0);
const number = n => new Intl.NumberFormat("tr-TR").format(Number(n)||0);
const clamp = (n,min,max)=>Math.max(min,Math.min(max,n));
const escapeHtml = s => String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));

function discountPct(x){
  if(!x.marketPrice || Number(x.marketPrice)<=0) return 0;
  return Math.max(0, ((Number(x.marketPrice)-Number(x.auctionPrice))/Number(x.marketPrice))*100);
}
function hoursLeft(x){
  const d = new Date(x.deadline);
  return (d.getTime()-Date.now())/36e5;
}
function opportunityScore(x){
  const discount = discountPct(x);
  const urgency = hoursLeft(x) <= 24 ? 0.6 : hoursLeft(x) <= 72 ? 0.35 : 0;
  const ageBonus = Number(x.year)>=2022 ? 0.25 : Number(x.year)>=2020 ? 0.15 : 0;
  const marketQuality = Number(x.marketPrice)>0 ? 0.2 : -0.5;
  return clamp(4.2 + discount/7 + urgency + ageBonus + marketQuality,0,10).toFixed(1);
}
function deadlineText(x){
  const h = hoursLeft(x);
  if(h < 0) return "Kapanmış";
  if(h < 1) return `${Math.max(1,Math.round(h*60))} dk`;
  if(h < 24) return `${Math.round(h)} sa`;
  return `${Math.ceil(h/24)} gün`;
}
function dateText(v){
  const d=new Date(v); if(Number.isNaN(d.getTime())) return v||"—";
  return new Intl.DateTimeFormat("tr-TR",{day:"2-digit",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"}).format(d);
}
function unique(key){ return [...new Set(state.listings.map(x=>x[key]).filter(Boolean))].sort((a,b)=>String(a).localeCompare(String(b),"tr")); }
function toast(title, body=""){
  const box=document.createElement("div"); box.className="toast";
  box.innerHTML=`<strong>${escapeHtml(title)}</strong>${body?`<span>${escapeHtml(body)}</span>`:""}`;
  $("toastStack").appendChild(box);
  setTimeout(()=>box.remove(),3300);
}
function persist(){
  STORE.set("ir_listings", state.listings);
  STORE.set("ir_favorites", [...state.favorites]);
  STORE.set("ir_alerts", state.alerts);
  STORE.set("ir_layout", state.layout);
  STORE.set("ir_theme", state.theme);
}
function setTheme(theme){
  state.theme=theme; document.documentElement.dataset.theme=theme; persist();
}
setTheme(state.theme);

const viewTitles={
  dashboard:"Genel Bakış",listings:"İhaleler",watchlist:"Takip Listesi",alerts:"Alarmlar",analytics:"Analitik",data:"Veri Merkezi"
};
function switchView(name){
  state.currentView=name;
  $$(".view").forEach(v=>v.classList.remove("active"));
  $$(".nav-item").forEach(v=>v.classList.toggle("active",v.dataset.view===name));
  const view=$(`view-${name}`); if(view) view.classList.add("active");
  $("pageTitle").textContent=viewTitles[name]||"İhaleRadar";
  if(name==="dashboard") renderDashboard();
  if(name==="listings") renderListings();
  if(name==="watchlist") renderWatchlist();
  if(name==="alerts") renderAlerts();
  if(name==="analytics") renderAnalytics();
  updateNav();
  closeSidebar();
  window.scrollTo({top:0,behavior:"smooth"});
}
$$("[data-view]").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.view)));
$$("[data-view-jump]").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.viewJump)));
$("goListingsBtn").addEventListener("click",()=>switchView("listings"));

function updateNav(){
  $("navListingCount").textContent=state.listings.length;
  $("navFavCount").textContent=state.favorites.size;
  $("navAlertCount").textContent=state.alerts.length;
}
function fillSelect(id, values, firstText){
  const sel=$(id); const current=sel.value;
  sel.innerHTML=`<option value="">${firstText}</option>`+values.map(v=>`<option value="${escapeHtml(v)}">${escapeHtml(v)}</option>`).join("");
  if(values.includes(current)) sel.value=current;
}
function refreshSelects(){
  fillSelect("brandFilter",unique("brand"),"Tümü");
  fillSelect("cityFilter",unique("city"),"Tümü");
  fillSelect("sourceFilter",unique("source"),"Tümü");
  fillSelect("alertBrand",unique("brand"),"Tüm markalar");
  fillSelect("alertCity",unique("city"),"Tüm şehirler");
}
refreshSelects();

function renderDashboard(){
  const data=state.listings;
  const avgDisc=data.length?data.reduce((s,x)=>s+discountPct(x),0)/data.length:0;
  const hot=data.filter(x=>Number(opportunityScore(x))>=8).length;
  const closing=data.filter(x=>hoursLeft(x)>=0&&hoursLeft(x)<=24).length;
  $("kpiListings").textContent=number(data.length);
  $("kpiSources").textContent=unique("source").length;
  $("kpiDiscount").textContent=`%${avgDisc.toFixed(1)}`;
  $("kpiHot").textContent=hot;
  $("kpiClosing").textContent=closing;
  $("heroBestScore").textContent=data.length?Math.max(...data.map(x=>Number(opportunityScore(x)))).toFixed(1):"—";

  const featured=[...data].sort((a,b)=>Number(opportunityScore(b))-Number(opportunityScore(a))).slice(0,5);
  $("featuredList").innerHTML=featured.map(x=>`
    <div class="featured-row">
      <div class="vehicle-main"><strong>${escapeHtml(x.brand)} ${escapeHtml(x.model)}</strong><small>${x.year} • ${escapeHtml(x.city)} • ${escapeHtml(x.source)}</small></div>
      <div class="metric-cell"><span>İhale</span><strong>${money(x.auctionPrice)}</strong></div>
      <div class="metric-cell"><span>Avantaj</span><strong class="positive">%${discountPct(x).toFixed(1)}</strong></div>
      <div class="score-pill">${opportunityScore(x)}</div>
      <button class="link-btn" onclick="openDetail(${Number(x.id)})">İncele →</button>
    </div>`).join("");

  const counts={}; data.forEach(x=>counts[x.source]=(counts[x.source]||0)+1);
  const max=Math.max(1,...Object.values(counts));
  $("sourceMiniChart").innerHTML=Object.entries(counts).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`
    <div><div class="bar-line-head"><span>${escapeHtml(k)}</span><strong>${v}</strong></div><div class="bar-track"><div class="bar-fill" style="width:${(v/max)*100}%"></div></div></div>`).join("");

  const upcoming=[...data].filter(x=>hoursLeft(x)>=0).sort((a,b)=>hoursLeft(a)-hoursLeft(b)).slice(0,5);
  $("closingTimeline").innerHTML=upcoming.length?upcoming.map(x=>`
    <div class="timeline-item"><div class="time-badge">${deadlineText(x)}</div><div><strong>${escapeHtml(x.brand)} ${escapeHtml(x.model)}</strong><small>${escapeHtml(x.city)} • ${money(x.auctionPrice)}</small></div></div>`).join("")
    : `<p class="muted">Yaklaşan kapanış yok.</p>`;

  const brands={}; data.forEach(x=>{
    if(!brands[x.brand]) brands[x.brand]=[];
    brands[x.brand].push(Number(opportunityScore(x)));
  });
  $("brandStrip").innerHTML=Object.entries(brands).map(([brand,scores])=>({brand,avg:scores.reduce((a,b)=>a+b,0)/scores.length,count:scores.length}))
    .sort((a,b)=>b.avg-a.avg).slice(0,5).map(b=>`
      <button class="brand-chip" onclick="jumpToBrand('${String(b.brand).replace(/'/g,"\\'")}')">
        <strong>${escapeHtml(b.brand)}</strong><span>${b.count} ilan • Ort. ${b.avg.toFixed(1)}</span>
      </button>`).join("");
}
window.jumpToBrand=function(brand){
  switchView("listings"); $("brandFilter").value=brand; renderListings();
};

function getFilters(){
  return {
    q:$("searchFilter").value.trim().toLocaleLowerCase("tr"),
    brand:$("brandFilter").value,
    city:$("cityFilter").value,
    source:$("sourceFilter").value,
    minYear:Number($("minYearFilter").value)||0,
    maxPrice:Number($("maxPriceFilter").value)||Infinity,
    minScore:Number($("scoreFilter").value)||0,
    discount20:$("discount20Filter").checked,
    closingSoon:$("closingSoonFilter").checked
  };
}
function filteredListings(){
  const f=getFilters();
  let data=state.listings.filter(x=>{
    const hay=`${x.brand} ${x.model} ${x.city} ${x.source}`.toLocaleLowerCase("tr");
    return (!f.q||hay.includes(f.q))
      &&(!f.brand||x.brand===f.brand)
      &&(!f.city||x.city===f.city)
      &&(!f.source||x.source===f.source)
      &&Number(x.year)>=f.minYear
      &&Number(x.auctionPrice)<=f.maxPrice
      &&Number(opportunityScore(x))>=f.minScore
      &&(!f.discount20||discountPct(x)>=20)
      &&(!f.closingSoon||(hoursLeft(x)>=0&&hoursLeft(x)<=48));
  });
  const s=$("sortFilter").value;
  if(s==="score") data.sort((a,b)=>Number(opportunityScore(b))-Number(opportunityScore(a)));
  if(s==="discount") data.sort((a,b)=>discountPct(b)-discountPct(a));
  if(s==="closing") data.sort((a,b)=>hoursLeft(a)-hoursLeft(b));
  if(s==="priceAsc") data.sort((a,b)=>a.auctionPrice-b.auctionPrice);
  if(s==="priceDesc") data.sort((a,b)=>b.auctionPrice-a.auctionPrice);
  if(s==="yearDesc") data.sort((a,b)=>b.year-a.year);
  return data;
}
function cardHtml(x){
  const fav=state.favorites.has(Number(x.id));
  const comp=state.compare.has(Number(x.id));
  return `
    <article class="listing-card">
      <div class="card-banner"></div>
      <div class="card-body">
        <div class="card-head">
          <div>
            <div class="source-tag">${escapeHtml(x.source)} • DEMO</div>
            <h3 class="card-title">${escapeHtml(x.brand)} ${escapeHtml(x.model)}</h3>
            <div class="card-sub">${x.year} • ${escapeHtml(x.city)} • ${number(x.km||0)} km</div>
          </div>
          <div class="card-score">${opportunityScore(x)}</div>
        </div>
        <div class="card-price">
          <div class="price-cell"><span>İHALE FİYATI</span><strong>${money(x.auctionPrice)}</strong></div>
          <div class="price-cell"><span>TAHMİNİ PİYASA</span><strong>${money(x.marketPrice)}</strong></div>
        </div>
        <div class="advantage-row"><span>Potansiyel fiyat avantajı</span><strong>%${discountPct(x).toFixed(1)} • ${money(Number(x.marketPrice)-Number(x.auctionPrice))}</strong></div>
        <div class="deadline-row"><span>⏱ ${deadlineText(x)}</span><span>${dateText(x.deadline)}</span></div>
        <div class="card-actions">
          <button class="square-btn ${fav?"active":""}" onclick="toggleFavorite(${Number(x.id)})" title="Favori">${fav?"★":"☆"}</button>
          <button class="square-btn ${comp?"active":""}" onclick="toggleCompare(${Number(x.id)})" title="Karşılaştır">${comp?"✓":"⇄"}</button>
          <button class="detail-btn" onclick="openDetail(${Number(x.id)})">Detayı İncele</button>
        </div>
      </div>
    </article>`;
}
function rowHtml(x){
  return `<tr>
    <td><div class="table-vehicle"><strong>${escapeHtml(x.brand)} ${escapeHtml(x.model)}</strong><small>${x.year} • ${number(x.km||0)} km • ${escapeHtml(x.source)}</small></div></td>
    <td>${escapeHtml(x.city)}</td>
    <td>${money(x.auctionPrice)}</td>
    <td>${money(x.marketPrice)}</td>
    <td class="positive">%${discountPct(x).toFixed(1)}</td>
    <td><span class="score-pill">${opportunityScore(x)}</span></td>
    <td>${deadlineText(x)}</td>
    <td><button class="link-btn" onclick="openDetail(${Number(x.id)})">Aç</button></td>
  </tr>`;
}
function renderListings(){
  $("scoreFilterValue").textContent=Number($("scoreFilter").value).toFixed(1);
  const data=filteredListings();
  $("listingResultCount").textContent=data.length;
  $("listingCards").innerHTML=data.map(cardHtml).join("");
  $("listingTableBody").innerHTML=data.map(rowHtml).join("");
  $("listingEmpty").classList.toggle("hidden",data.length!==0);
  $("listingCards").classList.toggle("hidden",state.layout!=="cards");
  $("listingTableWrap").classList.toggle("hidden",state.layout!=="table");
  $$("#layoutToggle button").forEach(b=>b.classList.toggle("active",b.dataset.layout===state.layout));
  renderCompareBar();
}
const filterIds=["searchFilter","brandFilter","cityFilter","sourceFilter","minYearFilter","maxPriceFilter","scoreFilter","discount20Filter","closingSoonFilter","sortFilter"];
filterIds.forEach(id=>$(id).addEventListener("input",renderListings));
$("resetFilters").addEventListener("click",resetFilters);
$("emptyReset").addEventListener("click",resetFilters);
function resetFilters(){
  ["searchFilter","brandFilter","cityFilter","sourceFilter","minYearFilter","maxPriceFilter"].forEach(id=>$(id).value="");
  $("scoreFilter").value=0;$("discount20Filter").checked=false;$("closingSoonFilter").checked=false;$("sortFilter").value="score";renderListings();
}
$$("#layoutToggle button").forEach(b=>b.addEventListener("click",()=>{state.layout=b.dataset.layout;persist();renderListings();}));

window.toggleFavorite=function(id){
  id=Number(id);
  state.favorites.has(id)?state.favorites.delete(id):state.favorites.add(id);
  persist();updateNav();
  if(state.currentView==="listings")renderListings();
  if(state.currentView==="watchlist")renderWatchlist();
  toast(state.favorites.has(id)?"Takip listesine eklendi":"Takip listesinden çıkarıldı");
};
window.toggleCompare=function(id){
  id=Number(id);
  if(state.compare.has(id))state.compare.delete(id);
  else{
    if(state.compare.size>=3){toast("En fazla 3 araç","Karşılaştırma için bir aracı çıkar.");return;}
    state.compare.add(id);
  }
  renderListings();
};
function renderCompareBar(){
  $("compareCount").textContent=state.compare.size;
  $("compareBar").classList.toggle("hidden",state.compare.size===0);
}
$("clearCompare").addEventListener("click",()=>{state.compare.clear();renderListings();});
$("openCompare").addEventListener("click",openCompareModal);
$("closeCompareModal").addEventListener("click",()=>$("compareModal").close());
function openCompareModal(){
  const items=state.listings.filter(x=>state.compare.has(Number(x.id)));
  if(items.length<2){toast("En az 2 araç seç","Karşılaştırma için 2 veya 3 araç seç.");return;}
  const rows=[
    ["Araç",...items.map(x=>`${x.brand} ${x.model}`)],
    ["Yıl",...items.map(x=>x.year)],
    ["Şehir",...items.map(x=>x.city)],
    ["Kaynak",...items.map(x=>x.source)],
    ["İhale fiyatı",...items.map(x=>money(x.auctionPrice))],
    ["Tahmini piyasa",...items.map(x=>money(x.marketPrice))],
    ["Avantaj",...items.map(x=>`%${discountPct(x).toFixed(1)}`)],
    ["Fırsat skoru",...items.map(x=>opportunityScore(x))],
    ["KM",...items.map(x=>number(x.km||0))],
    ["Kapanış",...items.map(x=>deadlineText(x))]
  ];
  $("compareTableWrap").innerHTML=`<table class="compare-table">${rows.map((r,i)=>`<tr>${r.map((c,j)=>i===0||j===0?`<th>${escapeHtml(c)}</th>`:`<td>${escapeHtml(c)}</td>`).join("")}</tr>`).join("")}</table>`;
  $("compareModal").showModal();
}

function renderWatchlist(){
  const items=state.listings.filter(x=>state.favorites.has(Number(x.id)));
  $("watchlistCards").innerHTML=items.map(cardHtml).join("");
  $("watchlistEmpty").classList.toggle("hidden",items.length!==0);
}

window.openDetail=function(id){
  const x=state.listings.find(v=>Number(v.id)===Number(id)); if(!x)return;
  $("drawerTitle").textContent=`${x.brand} ${x.model}`;
  $("drawerContent").innerHTML=`
    <div class="detail-scorebox">
      <div class="big-score"><div><strong>${opportunityScore(x)}</strong><span>FIRSAT SKORU / 10</span></div></div>
      <div class="detail-kpis">
        <div class="detail-kpi"><span>İHALE FİYATI</span><strong>${money(x.auctionPrice)}</strong></div>
        <div class="detail-kpi"><span>TAHMİNİ PİYASA</span><strong>${money(x.marketPrice)}</strong></div>
        <div class="detail-kpi"><span>FİYAT AVANTAJI</span><strong class="positive">%${discountPct(x).toFixed(1)}</strong></div>
        <div class="detail-kpi"><span>KAPANIŞ</span><strong>${deadlineText(x)}</strong></div>
      </div>
    </div>
    <div class="detail-section">
      <h3>Araç bilgileri</h3>
      <div class="detail-list">
        <div class="detail-row"><span>Marka / Model</span><strong>${escapeHtml(x.brand)} ${escapeHtml(x.model)}</strong></div>
        <div class="detail-row"><span>Model yılı</span><strong>${x.year}</strong></div>
        <div class="detail-row"><span>Kilometre</span><strong>${number(x.km||0)} km</strong></div>
        <div class="detail-row"><span>Yakıt / Vites</span><strong>${escapeHtml(x.fuel||"—")} / ${escapeHtml(x.gear||"—")}</strong></div>
        <div class="detail-row"><span>Şehir</span><strong>${escapeHtml(x.city)}</strong></div>
        <div class="detail-row"><span>Kaynak</span><strong>${escapeHtml(x.source)} • Demo</strong></div>
        <div class="detail-row"><span>Kapanış zamanı</span><strong>${dateText(x.deadline)}</strong></div>
      </div>
    </div>
    <div class="detail-section">
      <h3>Skor nasıl okunmalı?</h3>
      <p class="muted">Skor, demo sürümünde fiyat avantajı, kapanış yakınlığı ve model yılı gibi basit değişkenlerle hesaplanır. Hasar, ekspertiz, hukuki durum ve gerçek piyasa karşılaştırması yapılmadan yatırım kararı verilmemelidir.</p>
    </div>
    <div class="drawer-actions">
      <button class="secondary-btn" onclick="toggleFavorite(${Number(x.id)});openDetail(${Number(x.id)})">${state.favorites.has(Number(x.id))?"★ Takipten çıkar":"☆ Takibe al"}</button>
      <button class="primary-btn" onclick="toast('Demo kaynak','Gerçek sürümde resmi ihale sayfası burada açılır.')">Resmi ilana git</button>
    </div>`;
  $("detailDrawer").classList.add("open");$("detailDrawer").setAttribute("aria-hidden","false");$("drawerOverlay").classList.remove("hidden");
};
function closeDetail(){$("detailDrawer").classList.remove("open");$("detailDrawer").setAttribute("aria-hidden","true");$("drawerOverlay").classList.add("hidden");}
$("closeDrawer").addEventListener("click",closeDetail);$("drawerOverlay").addEventListener("click",closeDetail);

function openAlertModal(prefill=false){
  if(prefill){
    const f=getFilters();
    $("alertBrand").value=f.brand||"";$("alertCity").value=f.city||"";$("alertMinScore").value=f.minScore||8;
    $("alertMaxPrice").value=Number.isFinite(f.maxPrice)?f.maxPrice:"";
    $("alertName").value=[f.city,f.brand].filter(Boolean).join(" ")||"Yeni fırsat alarmı";
  }else{
    $("alertForm").reset();$("alertMinScore").value=8;
  }
  $("alertModal").showModal();
}
["quickAlertBtn","heroAlertBtn","newAlertBtn","alertsEmptyBtn"].forEach(id=>$(id).addEventListener("click",()=>openAlertModal(false)));
$("saveCurrentAlert").addEventListener("click",()=>openAlertModal(true));
$("createAlertBtn").addEventListener("click",e=>{
  e.preventDefault();
  const name=$("alertName").value.trim(); if(!name){toast("Alarm adı gerekli");return;}
  state.alerts.push({
    id:Date.now(),name,brand:$("alertBrand").value,city:$("alertCity").value,
    minScore:Number($("alertMinScore").value)||0,maxPrice:Number($("alertMaxPrice").value)||null,
    channel:$("alertChannel").value,active:true,createdAt:new Date().toISOString()
  });
  persist();$("alertModal").close();updateNav();renderAlerts();toast("Alarm kaydedildi",name);
});
function renderAlerts(){
  $("alertGrid").innerHTML=state.alerts.map(a=>`
    <article class="alert-card">
      <div class="alert-card-head"><div><h3>${escapeHtml(a.name)}</h3><small>${escapeHtml(a.channel)}</small></div><button class="icon-only" onclick="deleteAlert(${Number(a.id)})">×</button></div>
      <div class="alert-rule">
        <span class="rule-chip">${a.brand?escapeHtml(a.brand):"Tüm markalar"}</span>
        <span class="rule-chip">${a.city?escapeHtml(a.city):"Tüm şehirler"}</span>
        <span class="rule-chip">${Number(a.minScore).toFixed(1)}+ skor</span>
        ${a.maxPrice?`<span class="rule-chip">${money(a.maxPrice)} altı</span>`:""}
      </div>
      <div class="alert-foot"><span>${new Date(a.createdAt).toLocaleDateString("tr-TR")} tarihinde oluşturuldu</span><button class="toggle ${a.active?"on":""}" onclick="toggleAlert(${Number(a.id)})"></button></div>
    </article>`).join("");
  $("alertsEmpty").classList.toggle("hidden",state.alerts.length!==0);
}
window.deleteAlert=function(id){state.alerts=state.alerts.filter(a=>Number(a.id)!==Number(id));persist();updateNav();renderAlerts();toast("Alarm silindi");};
window.toggleAlert=function(id){const a=state.alerts.find(a=>Number(a.id)===Number(id));if(a)a.active=!a.active;persist();renderAlerts();};

function renderAnalytics(){
  const data=state.listings;
  const byBrand={}; data.forEach(x=>{(byBrand[x.brand]??=[]).push(discountPct(x));});
  const brandStats=Object.entries(byBrand).map(([k,v])=>[k,v.reduce((a,b)=>a+b,0)/v.length]).sort((a,b)=>b[1]-a[1]).slice(0,8);
  const maxB=Math.max(1,...brandStats.map(x=>x[1]));
  $("brandDiscountChart").innerHTML=brandStats.map(([k,v])=>`
    <div class="bar-row"><strong>${escapeHtml(k)}</strong><div class="bar-track large"><div class="bar-fill" style="width:${v/maxB*100}%"></div></div><span>%${v.toFixed(1)}</span></div>`).join("");

  const cities={};data.forEach(x=>cities[x.city]=(cities[x.city]||0)+1);
  $("cityRank").innerHTML=Object.entries(cities).sort((a,b)=>b[1]-a[1]).slice(0,7).map(([k,v],i)=>`
    <div class="rank-item"><div class="rank-no">${i+1}</div><strong>${escapeHtml(k)}</strong><span>${v} ilan</span></div>`).join("");

  const high=data.filter(x=>Number(opportunityScore(x))>=8).length;
  const mid=data.filter(x=>Number(opportunityScore(x))>=6&&Number(opportunityScore(x))<8).length;
  const low=Math.max(0,data.length-high-mid);
  const total=Math.max(1,data.length);
  $("donutHot").textContent=high;
  const pHigh=high/total*100,pMid=mid/total*100;
  $("scoreDonut").style.background=`conic-gradient(var(--positive) 0 ${pHigh}%, var(--warning) ${pHigh}% ${pHigh+pMid}%, var(--line2) ${pHigh+pMid}% 100%)`;
  $("scoreLegend").innerHTML=`
    <div class="legend-item"><span class="legend-dot" style="background:var(--positive)"></span>8+ skor • ${high}</div>
    <div class="legend-item"><span class="legend-dot" style="background:var(--warning)"></span>6–7.9 • ${mid}</div>
    <div class="legend-item"><span class="legend-dot" style="background:var(--line2)"></span>6 altı • ${low}</div>`;

  const bands=[
    ["0–1M",0,1_000_000],["1–1.5M",1_000_000,1_500_000],["1.5–2M",1_500_000,2_000_000],
    ["2–3M",2_000_000,3_000_000],["3M+",3_000_000,Infinity]
  ].map(([label,min,max])=>[label,data.filter(x=>x.auctionPrice>=min&&x.auctionPrice<max).length]);
  const maxBand=Math.max(1,...bands.map(x=>x[1]));
  $("priceBandChart").innerHTML=bands.map(([k,v])=>`
    <div class="bar-row"><strong>${k}</strong><div class="bar-track large"><div class="bar-fill" style="width:${v/maxBand*100}%"></div></div><span>${v} araç</span></div>`).join("");
}

function csvEscape(v){const s=String(v??"");return /[",\n]/.test(s)?`"${s.replace(/"/g,'""')}"`:s;}
function toCsv(rows){
  const cols=["source","brand","model","year","city","auctionPrice","marketPrice","deadline","km","fuel","gear","url"];
  return [cols.join(","),...rows.map(r=>cols.map(c=>csvEscape(r[c])).join(","))].join("\n");
}
function downloadText(name,text,type="text/plain"){
  const blob=new Blob([text],{type});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
$("downloadTemplate").addEventListener("click",()=>downloadText("ihale-radar-sablon.csv","source,brand,model,year,city,auctionPrice,marketPrice,deadline,url\nGİB,Mercedes-Benz,E 220 d,2018,Gaziantep,1080000,1520000,2026-08-27T16:00:00,https://ornek.gov.tr/ilan","text/csv;charset=utf-8"));
$("exportDataBtn").addEventListener("click",()=>downloadText("ihale-radar-veri.csv","\ufeff"+toCsv(state.listings),"text/csv;charset=utf-8"));
$("exportAnalyticsBtn").addEventListener("click",()=>downloadText("ihale-radar-analitik.csv","\ufeff"+toCsv(state.listings),"text/csv;charset=utf-8"));

function parseCsv(text){
  const rows=[];let row=[],cell="",q=false;
  for(let i=0;i<text.length;i++){
    const ch=text[i],next=text[i+1];
    if(ch==='"'&&q&&next==='"'){cell+='"';i++;}
    else if(ch==='"'){q=!q;}
    else if(ch===","&&!q){row.push(cell);cell="";}
    else if((ch==="\n"||ch==="\r")&&!q){
      if(ch==="\r"&&next==="\n")i++;
      row.push(cell);cell="";
      if(row.some(v=>v.trim()!==""))rows.push(row);
      row=[];
    }else cell+=ch;
  }
  if(cell.length||row.length){row.push(cell);rows.push(row);}
  if(rows.length<2)return [];
  const headers=rows[0].map(h=>h.trim());
  return rows.slice(1).map((r,idx)=>{
    const o={};headers.forEach((h,i)=>o[h]=(r[i]??"").trim());
    return {
      id:Date.now()+idx,source:o.source||"CSV",brand:o.brand||"Belirsiz",model:o.model||"Belirsiz",
      year:Number(o.year)||0,city:o.city||"Belirsiz",auctionPrice:Number(o.auctionPrice)||0,marketPrice:Number(o.marketPrice)||0,
      deadline:o.deadline||new Date(Date.now()+864e5*7).toISOString(),km:Number(o.km)||0,fuel:o.fuel||"",gear:o.gear||"",url:o.url||"#",note:"CSV içe aktarım"
    };
  }).filter(x=>x.brand&&x.model);
}
async function handleCsv(file){
  if(!file)return;
  const text=await file.text();const imported=parseCsv(text);
  if(!imported.length){toast("CSV okunamadı","Şablondaki sütunları kontrol et.");return;}
  state.listings=[...state.listings,...imported];persist();refreshSelects();renderAll();toast(`${imported.length} ilan eklendi`,"CSV içe aktarma tamamlandı.");
}
$("csvFile").addEventListener("change",e=>handleCsv(e.target.files[0]));
const dz=$("dropzone");
["dragenter","dragover"].forEach(evt=>dz.addEventListener(evt,e=>{e.preventDefault();dz.classList.add("drag");}));
["dragleave","drop"].forEach(evt=>dz.addEventListener(evt,e=>{e.preventDefault();dz.classList.remove("drag");}));
dz.addEventListener("drop",e=>handleCsv(e.dataTransfer.files[0]));
$("resetDemoBtn").addEventListener("click",()=>{
  if(confirm("İçe aktardığın veriler silinip demo veri setine dönülsün mü?")){
    state.listings=DEMO_LISTINGS.map(x=>({...x}));state.favorites.clear();state.compare.clear();persist();refreshSelects();renderAll();toast("Demo verisine dönüldü");
  }
});

$("globalSearch").addEventListener("input",e=>{
  if(state.currentView!=="listings")switchView("listings");
  $("searchFilter").value=e.target.value;renderListings();
});
document.addEventListener("keydown",e=>{
  if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==="k"){e.preventDefault();$("globalSearch").focus();}
  if(e.key==="Escape")closeDetail();
});
$("themeToggle").addEventListener("click",()=>setTheme(state.theme==="dark"?"light":"dark"));

function openSidebar(){$("sidebar").classList.add("open");$("sidebarOverlay").classList.remove("hidden");}
function closeSidebar(){$("sidebar").classList.remove("open");$("sidebarOverlay").classList.add("hidden");}
$("openSidebar").addEventListener("click",openSidebar);$("closeSidebar").addEventListener("click",closeSidebar);$("sidebarOverlay").addEventListener("click",closeSidebar);

function renderAll(){updateNav();renderDashboard();renderListings();renderWatchlist();renderAlerts();renderAnalytics();}
renderAll();
