# İhaleRadar Pro — Gelişmiş MVP

Bu klasör, kamu araç ihalelerini tek ekranda incelemek için hazırlanmış **tamamen statik, ücretsiz çalışabilen gelişmiş prototiptir**.

## Özellikler
- Profesyonel responsive dashboard
- Marka / şehir / kaynak / yıl / fiyat / skor filtreleri
- Fırsat skoru ve fiyat avantajı hesabı
- Kart / tablo görünümü
- Favori / takip listesi
- 2–3 araç yan yana karşılaştırma
- Filtre bazlı alarm oluşturma (localStorage demo)
- Kaynak, şehir, marka ve fiyat analitiği
- CSV içe aktarma
- CSV dışa aktarma
- Demo veri resetleme
- Koyu / açık tema
- Mobil sidebar
- LocalStorage ile tarayıcıda veri saklama

## Önemli
Bu prototipteki ilanlar **örnek veridir**. GİB, UYAP ve Ticaret Bakanlığı canlı veri akışları bağlı değildir.

Canlı sürüme geçmeden önce her resmi kaynağın API, robots, kullanım koşulları, yeniden yayınlama ve otomatik erişim şartları ayrıca doğrulanmalıdır.

## Bilgisayarda aç
`index.html` dosyasına çift tıkla. Sunucu gerektirmez.

## Vercel / Netlify / Cloudflare Pages
Bu klasörü GitHub repository'sine yükleyip statik site olarak yayınlayabilirsin. Build komutu gerekmez.

## CSV şeması
`source, brand, model, year, city, auctionPrice, marketPrice, deadline, url`

Opsiyonel:
`km, fuel, gear`

`deadline` için ISO tarih biçimi önerilir:
`2026-08-27T16:00:00`

## Ürüne çevirmek için sonraki aşama
1. Supabase/Postgres veritabanı
2. Kullanıcı kayıt/giriş
3. Sunucu tarafı veri toplayıcı
4. Resmi kaynak entegrasyonu
5. Gerçek piyasa fiyat karşılaştırması
6. E-posta/WhatsApp bildirimleri
7. Stripe/iyzico abonelik sistemi
8. Yetkilendirme + admin paneli
9. Loglama, rate limit, KVKK metinleri
10. SEO landing sayfaları
